// Simple predefined Q&A
const responses = {
  "hi": "Hello 👋! I'm your career advisor. Ask me about courses, colleges, or scholarships!",
  "hello": "Hello 👋! How can I help you today?",
  "courses": "You can pursue Engineering, Medical, Commerce, Arts, or Vocational courses after 12th. Which stream are you interested in?",
  "scholarship": "💡 Many scholarships are available! Example: National Scholarship Portal (NSP), private foundations, and state-level schemes.",
  "college": "You can explore colleges through CUET, state exams, or private universities. Want suggestions for a state or stream?",
  "engineering": "Great choice! You can prepare for JEE, state engineering entrances, or private exams.",
  "medical": "You should aim for NEET-UG if you want to become a doctor or dentist.",
  "bye": "Goodbye 👋. Come back anytime for guidance!"
};

console.log("✅ Chatbot JS loaded");

// Wait for DOM
document.addEventListener("DOMContentLoaded", () => {
  const chatIcon = document.getElementById("chat-icon");
  const chatbot = document.getElementById("chatbot");
  const chatToggle = document.getElementById("chat-toggle");
  const chatMessages = document.getElementById("chat-messages");
  const chatInput = document.getElementById("chat-input");
  const chatSend = document.getElementById("chat-send");
  const quickRoot = document.getElementById("chat-quick");

  console.log("DOM ready - elements:", { chatIcon, chatbot, chatToggle, chatMessages, chatInput, chatSend, quickRoot });

  // show a welcome bot message
  appendMessage("bot", "Hi! I'm Mind Morph Advisor. Try typing 'courses', 'scholarship' or click a quick button below.");

  // Open chat
  chatIcon.addEventListener("click", () => {
    chatbot.style.display = "flex";
    chatIcon.style.display = "none";
    chatInput.focus();
    console.log("Chat opened");
  });

  // Close chat
  chatToggle.addEventListener("click", () => {
    chatbot.style.display = "none";
    chatIcon.style.display = "block";
    console.log("Chat closed");
  });

  // Send typed message
  function sendMessage() {
    const userMsg = (chatInput.value || "").trim();
    if (!userMsg) return;

    appendMessage("user", userMsg);
    chatInput.value = "";
    chatInput.focus();
    console.log("User sent:", userMsg);

    // Bot replies after a small delay
    setTimeout(() => {
      let reply = "❓ Sorry, I don't understand that. Try 'courses', 'college', or 'scholarship'.";
      const key = Object.keys(responses).find(k => userMsg.toLowerCase().includes(k));
      if (key) reply = responses[key];
      appendMessage("bot", reply);
      console.log("Bot replied:", reply);
    }, 450);
  }

  // Hook events
  chatSend.addEventListener("click", sendMessage);
  chatInput.addEventListener("keydown", (e) => { if (e.key === "Enter") sendMessage(); });

  // Quick reply buttons (delegation)
  quickRoot.addEventListener("click", (e) => {
    if (e.target && e.target.matches("button.quick")) {
      const q = e.target.dataset.q;
      chatInput.value = q;
      sendMessage();
    }
  });

  // Append message helper
  function appendMessage(sender, text) {
    const div = document.createElement("div");
    div.className = `message ${sender}`;
    div.textContent = text;
    chatMessages.appendChild(div);
    // keep scroll at bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
});
